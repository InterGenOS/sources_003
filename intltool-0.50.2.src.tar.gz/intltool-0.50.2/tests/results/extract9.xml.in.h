char *s = N_("Welcome to The GIMP !");
char *s = N_("Nearly all image operations are performed by right-clicking on the image. And don't worry, you can undo most mistakes.");
char *s = N_("\n"
             "\n"
             "\n"
             "      This tip should have lots of whitespace around it\n"
             "\n"
             "\n"
             "\n"
             "    ");
