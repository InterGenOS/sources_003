# 3 "cases/extract10.templates_"
/* Default
 This comment is inserted in PO files to help translators */
char *s = N_("US");
# 5 "cases/extract10.templates_"
/* Description */
char *s = N_("Select Area");
# 5 "cases/extract10.templates_"
/* Description */
char *s = N_("Please select your geographical area from the choices provided.  If you are in the United States, you can just use the US option.  You can also find UTC and GMT-offset zone settings in the Etc directory.");
# 13 "cases/extract10.templates_"
/* Description */
char *s = N_("Time zone");
# 13 "cases/extract10.templates_"
/* Description */
char *s = N_("Please select the time zone that is appropriate for your location.");
# 18 "cases/extract10.templates_"
/* Choices */
char *s = N_("January, February, March, April, May, June, July, August, September, October, November, December");
# 19 "cases/extract10.templates_"
/* Description */
char *s = N_("Current month?");
