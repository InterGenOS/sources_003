char *s = C_("Dots Per Inch", "DPI");
char *s = N_("The resolution used for converting font sizes to pixel sizes, in dots per inch.");
char *s = N_("'space   preserved   properly'");
char *s = N_("This is a complicated key.");
char *s = C_("GSettings description", "This key is very complicated. You should not attempt to understand it.\n"
             "\n"
             "There was this one guy who attempted to make sense of it once. We don't know what happened to him.");
/*  Translators: translate to either 12 or 24 to define the default
           clock format.  */
char *s = C_("clock-format", "24");
char *s = N_("Time format");
char *s = C_("Time format gsettings description", "How many hours can you tell apart?");
char *s = N_("This is a key with multiple newlines.");
char *s = C_("GSettings description", "Paragraph one. Please keep the whitespace indentation in empty lines for testing as well.\n"
             "\n"
             "Paragraph two. There was never anyone who tried to make sense out of this.");
