# 1 "cases/test-quoted.dtd"
char *s = N_("Channel requires &quot;authentication&quot;");
# 2 "cases/test-quoted.dtd"
char *s = N_("Please enter the username and password given to you by this channel's publisher.");
# 3 "cases/test-quoted.dtd"
char *s = N_("Username\"foo\":");
# 4 "cases/test-quoted.dtd"
char *s = N_("Password\\a:");
