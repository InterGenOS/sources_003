char *s = N_("Are you sure you want\n"
             "to delete this contact?");
