char *s = N_("Europe");
/*  Translators: This is in France.  */
char *s = N_("Chambéry");
/*  Translators: This is in Chambéry in France.  */
char *s = N_("Aix-les-Bains");
