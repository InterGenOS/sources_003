char *s = N_("Europe");
/*  Translators: This is in France.  */
char *s = N_("Chamb�ry");
/*  Translators: This is in Chamb�ry in France.  */
char *s = N_("Aix-les-Bains");
