char *s = N_("The &lt; entity produces the < character");
char *s = N_("The &gt; entity produces the > character");
char *s = N_("The &amp;lt; entity produces the &lt; character");
char *s = N_("The &amp;gt; entity produces the &gt; character");
