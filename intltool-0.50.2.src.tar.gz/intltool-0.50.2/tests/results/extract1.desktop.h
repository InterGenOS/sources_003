char *s = N_("Nautilus");
char *s = N_("Nautilus File Manager and Graphic Shell");
