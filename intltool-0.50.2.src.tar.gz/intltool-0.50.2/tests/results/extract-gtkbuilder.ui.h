char *s = N_("help");
char *s = C_("user", "help");
char *s = C_("developer", "help");
