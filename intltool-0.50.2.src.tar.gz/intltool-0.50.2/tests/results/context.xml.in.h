char *s = N_("Foo");
/*  This is the comment on the first Bar  */
char *s = C_("1", "Bar");
/*  This is the comment on the second Bar  */
char *s = C_("2", "Bar");
/*  This is the comment on Baz  */
char *s = N_("Baz");
