/*  default value for /schemas/apps/clock_applet/prefs/hour_format  
                    The translation should only include the localized default
                    eg. 12 or 24  */
char *s = N_("24");
char *s = N_("Hour format");
char *s = N_("Sets the hour format, may be either 12 or 24");
char *s = N_("Display seconds in time");
char *s = N_("12");
char *s = N_("Something random..even has >");
char *s = N_("Puh long.");
