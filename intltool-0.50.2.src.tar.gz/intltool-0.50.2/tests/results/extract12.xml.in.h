char *s = N_("Other attribute");
char *s = N_("Normal name");
char *s = N_("Other name");
