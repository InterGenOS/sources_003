char *s = N_("Insufficient disk space for upgrade.");
char *s = N_("Upgrading your data and settings will require up to {0} of disk\n"
             "space, but you only have {1} available.\n"
             "\n"
             "You will need to make more space available in your home directory before you can\n"
             "continue.");
char *s = N_("This is not an error.");
char *s = N_("And this message should take no more than one single row, no matter the spacing in the source file.");
