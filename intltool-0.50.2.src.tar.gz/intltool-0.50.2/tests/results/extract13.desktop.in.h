/*  2. This comment should be extracted. */
char *s = N_("Find Files...");
/*  4. This comment also should be extracted. */
char *s = N_("Locate documents and folders on this computer by name or content");
char *s = N_("Blue");
