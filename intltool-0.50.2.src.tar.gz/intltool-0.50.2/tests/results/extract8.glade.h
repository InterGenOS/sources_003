char *s = N_("_New Window");
char *s = N_("_New Tab");
char *s = N_("_Quit");
char *s = N_("Testing");
/* Comment on <property> tag */
char *s = N_("A label");
/* Multiline comments
should be supported as well */
char *s = N_("_Push me");
char *s = N_("Testing2");
char *s = N_("Click the button below");
char *s = N_("This button\n"
             "dares you to invoke this action.");
char *s = N_("This action\n"
             "does nothing interesting.");
char *s = N_("Cancel (and exit) the test.");
