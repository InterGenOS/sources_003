#ifndef PROCPS_NG_FILEUTILS
#define PROCPS_NG_FILEUTILS

int close_stream(FILE * stream);
void close_stdout(void);

#endif
