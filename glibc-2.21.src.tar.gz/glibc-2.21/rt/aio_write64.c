#define BE_AIO64
#include <aio_write.c>
