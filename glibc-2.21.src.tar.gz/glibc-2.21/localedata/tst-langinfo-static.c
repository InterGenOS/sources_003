#include "tst-langinfo.c"
