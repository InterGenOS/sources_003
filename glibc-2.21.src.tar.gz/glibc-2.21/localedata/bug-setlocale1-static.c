#include "bug-setlocale1.c"
