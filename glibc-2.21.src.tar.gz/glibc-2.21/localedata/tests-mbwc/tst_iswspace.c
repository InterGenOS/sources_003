/*
  ISWSPACE: int iswspace (wint_t wc);
*/

#define TST_FUNCTION iswspace

#include "tsp_common.c"
#include "dat_iswspace.c"

TST_FUNC_ISW (SPACE, space);
