/*
  ISWALNUM: int iswalnum (wint_t wc)
*/

#define TST_FUNCTION iswalnum

#include "tsp_common.c"
#include "dat_iswalnum.c"

TST_FUNC_ISW (ALNUM, alnum);
