/*
  ISWPUNCT: int iswpunct (wint_t wc);
*/

#define TST_FUNCTION iswpunct

#include "tsp_common.c"
#include "dat_iswpunct.c"

TST_FUNC_ISW (PUNCT, punct);
