/*
  ISWXDIGIT: int iswxdigit (wint_t wc);
*/

#define TST_FUNCTION iswxdigit

#include "tsp_common.c"
#include "dat_iswxdigit.c"

TST_FUNC_ISW (XDIGIT, xdigit);
