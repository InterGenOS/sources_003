/*
  ISWGRAPH: int iswgraph (wint_t wc);
*/

#define TST_FUNCTION iswgraph

#include "tsp_common.c"
#include "dat_iswgraph.c"

TST_FUNC_ISW (GRAPH, graph);
