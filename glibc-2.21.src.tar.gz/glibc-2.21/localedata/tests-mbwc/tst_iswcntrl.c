/*
  ISWCNTRL: int iswcntrl (wint_t wc);
*/

#define TST_FUNCTION iswcntrl

#include "tsp_common.c"
#include "dat_iswcntrl.c"

TST_FUNC_ISW (CNTRL, cntrl);
