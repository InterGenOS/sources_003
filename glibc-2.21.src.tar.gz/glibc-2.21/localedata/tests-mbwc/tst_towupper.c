/*
  TOWUPPER: int towupper (wint_t wc);
*/

#define TST_FUNCTION towupper

#include "tsp_common.c"
#include "dat_towupper.c"

TST_FUNC_TOW (UPPER, upper);
