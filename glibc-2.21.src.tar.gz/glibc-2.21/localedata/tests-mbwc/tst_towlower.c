/*
  TOWLOWER: int towlower (wint_t wc);
*/

#define TST_FUNCTION towlower

#include "tsp_common.c"
#include "dat_towlower.c"


TST_FUNC_TOW (LOWER, lower);
