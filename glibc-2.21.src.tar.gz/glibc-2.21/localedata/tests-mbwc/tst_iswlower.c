/*
  ISWLOWER: int iswlower (wint_t wc);
*/

#define TST_FUNCTION iswlower

#include "tsp_common.c"
#include "dat_iswlower.c"

TST_FUNC_ISW (LOWER, lower);
