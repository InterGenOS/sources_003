/*
  ISWDIGIT: int iswdigit (wint_t wc);
*/


#define TST_FUNCTION iswdigit

#include "tsp_common.c"
#include "dat_iswdigit.c"

TST_FUNC_ISW (DIGIT, digit);
