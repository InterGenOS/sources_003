/*
  ISWUPPER: int iswupper (wint_t wc);
*/

#define TST_FUNCTION iswupper

#include "tsp_common.c"
#include "dat_iswupper.c"

TST_FUNC_ISW (UPPER, upper);
