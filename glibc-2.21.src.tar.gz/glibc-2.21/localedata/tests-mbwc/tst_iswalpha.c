/*
  ISWALPHA: int iswalpha (wint_t wc);
*/

#define TST_FUNCTION iswalpha

#include "tsp_common.c"
#include "dat_iswalpha.c"

TST_FUNC_ISW (ALPHA, alpha);
