/*
  ISWPRINT: int iswprint (wint_t wc);
*/

#define TST_FUNCTION iswprint

#include "tsp_common.c"
#include "dat_iswprint.c"

TST_FUNC_ISW (PRINT, print);
