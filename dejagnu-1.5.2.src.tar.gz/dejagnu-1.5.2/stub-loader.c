/* Bleah!! */
int remote_debug = 0;

main() {
  set_debug_traps();
  breakpoint();
}
