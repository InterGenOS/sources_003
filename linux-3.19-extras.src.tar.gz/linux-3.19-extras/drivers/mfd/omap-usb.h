extern int omap_tll_init(struct usbhs_omap_platform_data *pdata);
extern int omap_tll_enable(struct usbhs_omap_platform_data *pdata);
extern int omap_tll_disable(struct usbhs_omap_platform_data *pdata);
