obsolete_lib(sd_id128_to_string,libsystemd-id128);
obsolete_lib(sd_id128_from_string,libsystemd-id128);
obsolete_lib(sd_id128_randomize,libsystemd-id128);
obsolete_lib(sd_id128_get_machine,libsystemd-id128);
obsolete_lib(sd_id128_get_boot,libsystemd-id128);
