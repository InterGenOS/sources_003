/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Field layout of ostream class.  */
struct ostream_representation
{
  const void *vtable;
};
