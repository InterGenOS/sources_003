/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Field layout of superclass.  */
#include "ostream.priv.h"

/* Field layout of file_ostream class.  */
struct file_ostream_representation
{
  struct ostream_representation base;
  FILE *fp;
};
