#include "../gnulib-lib/html-styled-ostream.c"
