#include "../gnulib-lib/term-styled-ostream.c"
