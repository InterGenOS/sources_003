/* Obsolete; consider using parse-datetime.h instead.  */
#include "parse-datetime.h"
#define get_date(a, b, c) parse_datetime (a, b, c)
