# uses GDBM dbm compatibility feature
$self->{LIBS} = ['-lgdbm_compat -lgdbm'];
