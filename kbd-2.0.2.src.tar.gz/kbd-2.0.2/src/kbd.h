#ifndef _KBD_H
#define _KBD_H

#ifndef __GNUC__
#  define  __attribute__(x)  /*NOTHING*/
#endif

#endif /* _KBD_H */
