#if (!defined (__MINGW32__) || defined (__CYGWIN__)) && !defined (__AROS__)
#include "unix/exec.c"
#endif
