#if defined (__linux__)
#include "linux/emunet.c"
#else
#include "basic/emunet.c"
#endif
