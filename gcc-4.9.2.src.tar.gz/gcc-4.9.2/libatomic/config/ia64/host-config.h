/* Avoiding the synchronizations are a good thing.  */
#define WANT_SPECIALCASE_RELAXED
#define WANT_SPECIALCASE_ACQREL

#include_next <host-config.h>
