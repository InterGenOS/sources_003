#ifndef MONEY_H
#define MONEY_H

#endif /* MONEY_H */
