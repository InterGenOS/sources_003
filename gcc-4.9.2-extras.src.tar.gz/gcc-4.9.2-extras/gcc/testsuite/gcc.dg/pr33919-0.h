char *pre_inc_base_file = __BASE_FILE__;
