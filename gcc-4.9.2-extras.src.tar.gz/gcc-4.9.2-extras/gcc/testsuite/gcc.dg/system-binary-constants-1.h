#pragma GCC system_header

#define BINARY_INT_CONSTANT_IN_SYSTEM_HEADER 0b1101
