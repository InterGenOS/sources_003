typedef struct foo {
 int x;
} foo_t;
