union u { struct { int i; }; };

extern int foo (union u *);
