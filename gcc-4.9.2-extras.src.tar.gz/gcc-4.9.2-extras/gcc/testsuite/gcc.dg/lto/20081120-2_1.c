int mumble = 0;
void foo(void) {}
