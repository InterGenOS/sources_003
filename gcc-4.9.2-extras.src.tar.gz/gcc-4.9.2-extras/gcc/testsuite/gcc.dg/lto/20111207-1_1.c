/* { dg-options "-fno-lto" } */

int i;
