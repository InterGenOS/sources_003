extern int i;

int main()
{
  return i;
}
