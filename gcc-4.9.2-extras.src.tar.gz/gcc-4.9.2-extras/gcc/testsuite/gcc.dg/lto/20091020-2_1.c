typedef struct {
    int NumPackStreams;
} CSzAr;
void cli_7unz (CSzAr db) { }

