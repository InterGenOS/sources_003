typedef struct _IO_FILE FILE;
extern struct _IO_FILE *stderr;
