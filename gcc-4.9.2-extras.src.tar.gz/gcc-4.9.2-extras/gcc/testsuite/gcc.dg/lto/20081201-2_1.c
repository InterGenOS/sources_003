void *
foo (void)
{
  return __builtin_return_address (0);
}
