/* { dg-lto-do link } */
/* { dg-extra-ld-options {-r -nostdlib} } */

int i = 42;
