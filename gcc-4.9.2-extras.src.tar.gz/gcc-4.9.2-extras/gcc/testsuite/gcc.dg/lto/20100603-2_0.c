/* { dg-lto-do link } */
/* { dg-extra-ld-options {-r -nostdlib} } */

int foo;
int *i = &foo;
