extern int i[10];
int main () { return i[0]; }
