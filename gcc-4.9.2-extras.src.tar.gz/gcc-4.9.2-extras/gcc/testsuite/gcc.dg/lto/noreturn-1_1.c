int call_me (void);
int
main(void)
{
 return call_me ();
}
