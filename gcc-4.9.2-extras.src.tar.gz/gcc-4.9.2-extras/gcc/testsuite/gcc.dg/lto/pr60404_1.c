void
fn1 (int p)
{
}
