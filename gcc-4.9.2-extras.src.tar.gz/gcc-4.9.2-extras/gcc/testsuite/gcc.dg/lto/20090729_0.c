/* { dg-lto-options "-w" } */

double i;
int j;
