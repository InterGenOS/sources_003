extern void _moz_foo (void);
int
main()
{
  _moz_foo ();
  return 0;
}
