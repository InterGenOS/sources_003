int mumble = 41;

int
bar (void)
{
  return mumble;
}
