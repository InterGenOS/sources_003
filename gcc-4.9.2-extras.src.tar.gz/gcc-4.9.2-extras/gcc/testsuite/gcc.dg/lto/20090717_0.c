struct variable {
        const char *string;
};
struct variable table[] = { };
