extern const int i[];

int dummy(void) {
  return i[0];
}
