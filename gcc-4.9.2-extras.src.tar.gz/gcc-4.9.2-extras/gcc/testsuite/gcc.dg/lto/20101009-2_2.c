int bar (void)
{
  static int i;
  return ++i;
}
