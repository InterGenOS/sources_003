typedef struct{int x;} bar;
bar foo (void)
{
  bar x;
  return x;
}

