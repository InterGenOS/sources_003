double j;
int i;
int main () { return i; }

