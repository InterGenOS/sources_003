extern void *master;
void *bar () { return master; }
