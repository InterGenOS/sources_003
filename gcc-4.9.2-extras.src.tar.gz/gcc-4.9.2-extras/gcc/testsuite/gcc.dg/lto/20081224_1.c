#include "20081224_0.h"
foo_t x;
