void emit_push_insn () {
  set_mem_alias_set ();
}
