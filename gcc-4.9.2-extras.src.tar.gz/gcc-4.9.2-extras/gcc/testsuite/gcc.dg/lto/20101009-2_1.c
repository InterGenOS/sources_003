int foo (void)
{
  static int i;
  return ++i;
}
