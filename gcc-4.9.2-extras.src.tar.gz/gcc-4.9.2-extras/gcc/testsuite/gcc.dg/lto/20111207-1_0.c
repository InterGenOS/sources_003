/* { dg-lto-do run } */
/* { dg-lto-options { { -flto } } } */
/* { dg-require-linker-plugin "" } */
/* { dg-extra-ld-options "-fuse-linker-plugin" } */
