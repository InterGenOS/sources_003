/* { dg-lto-options {{ -O -flto -save-temps}} } */
/* { dg-lto-do link } */

int
main (void)
{
  return 0;
}

