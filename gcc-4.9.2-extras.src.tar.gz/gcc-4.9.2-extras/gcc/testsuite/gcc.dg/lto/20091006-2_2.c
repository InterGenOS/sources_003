extern int a[14];
