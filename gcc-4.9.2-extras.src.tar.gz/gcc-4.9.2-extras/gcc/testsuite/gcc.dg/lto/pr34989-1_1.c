struct globals *const ptr_to_globals;
