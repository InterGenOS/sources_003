int a[16];
