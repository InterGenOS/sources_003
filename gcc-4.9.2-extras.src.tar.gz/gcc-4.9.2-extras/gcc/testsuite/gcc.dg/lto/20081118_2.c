int
e_inline_baz (void)
{
 return 0;
}

 __attribute__((noinline)) int
f (void)
{
 return 1;
}
