#include "20091015-1_a.h"
#include "20091015-1_b.h"
void debug_optab_libfuncs (void) {
foo (stderr,       4         );
}
