#include "20091015-1_a.h"
#include "20091015-1_b.h"
void ggc_print_common_statistics (FILE *stream) {
}
