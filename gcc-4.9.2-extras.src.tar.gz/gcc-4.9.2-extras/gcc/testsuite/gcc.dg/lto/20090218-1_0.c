void inline set_mem_alias_set ()  __attribute__ ((always_inline));
void emit_push_insn () {
  set_mem_alias_set ();
}
