int main(void)
{
  return 0;
}
static void  __attribute__ ((noinline)) get_mem_attrs () {
}
void  inline __attribute__ ((always_inline)) set_mem_alias_set () {
  get_mem_attrs ();
}
