struct _IO_FILE { int _flags;
};
