extern int puts(const char *);
extern const char s[];

void f(void)
{
  puts(s);
}

