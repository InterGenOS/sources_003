/* { dg-lto-do run } */
/* { dg-require-linker-plugin "" } */
/* { dg-extra-ld-options "-fuse-linker-plugin" } */

int main() { return 0; }

