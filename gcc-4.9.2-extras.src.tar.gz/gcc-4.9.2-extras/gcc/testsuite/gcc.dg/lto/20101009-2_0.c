/* { dg-lto-do link } */

int main() { return 0; }
