/* { dg-lto-do link } */
/* { dg-extra-ld-options "-w" } */

extern int a[10];
int main() { return 0; }
