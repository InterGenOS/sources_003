int i;
