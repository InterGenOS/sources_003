int foo (int);

int main()
{
 return foo (0);
}
