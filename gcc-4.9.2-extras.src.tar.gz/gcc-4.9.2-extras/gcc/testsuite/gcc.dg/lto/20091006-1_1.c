extern void bar (void);
void check3 (void) { bar (); }
