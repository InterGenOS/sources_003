char *s = (char *) 0;
