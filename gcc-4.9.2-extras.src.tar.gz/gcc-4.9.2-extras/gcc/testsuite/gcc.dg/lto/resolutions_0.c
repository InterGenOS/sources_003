/* { dg-require-linker-plugin "" } */
/* { dg-extra-ld-options "-fuse-linker-plugin -O1" } */

link_error()
{
}
main()
{
  return 0;
}
