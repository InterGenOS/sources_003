int
e_inline_baz (void)
{
 return 0;
}


