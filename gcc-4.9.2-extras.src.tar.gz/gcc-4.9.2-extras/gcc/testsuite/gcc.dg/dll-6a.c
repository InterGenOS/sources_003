extern void i1();
extern void i3();
extern void i4();
extern void i5();

extern void e1();
extern void e3();
extern void e4();
extern void e5();

int main () {
  i1();
  i3();
  i4();
  i5();

  e1();
  e3();
  e4();
  e5();
}
