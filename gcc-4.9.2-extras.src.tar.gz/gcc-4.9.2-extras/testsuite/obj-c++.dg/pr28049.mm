/* { dg-do compile } */
+ /* { dg-error "expected" } */
