@interface /* { dg-error "expected identifier" } */
