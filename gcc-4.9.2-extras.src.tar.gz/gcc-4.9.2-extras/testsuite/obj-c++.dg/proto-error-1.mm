// PR obj-c++/28434
// { dg-do compile }

Class<> c;  // { dg-error "identifier" }
