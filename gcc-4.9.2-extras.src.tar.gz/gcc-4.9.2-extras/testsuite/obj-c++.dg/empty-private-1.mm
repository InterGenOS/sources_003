/* Test for no entry after @private token.  */

/* { do-do compile } */

@interface foo
{
@private
}
@end
