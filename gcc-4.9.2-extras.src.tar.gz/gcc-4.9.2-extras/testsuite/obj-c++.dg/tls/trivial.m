// { dg-require-effective-target tls }

__thread int i;
