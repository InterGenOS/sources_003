/* Simple test to check Objectivec-C++ qualified type lookup.  */
/* Devang Patel  <dpatel@apple.com>.  */

@interface A
{
   A *ap;
}
@end
