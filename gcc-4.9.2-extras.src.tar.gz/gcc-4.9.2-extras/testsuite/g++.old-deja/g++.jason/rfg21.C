// { dg-do assemble  }
char array0[4] = "abcde";          /* { dg-error "" } initializer too long */
