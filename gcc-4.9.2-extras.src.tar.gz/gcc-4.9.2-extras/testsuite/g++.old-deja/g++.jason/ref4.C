// { dg-do assemble  }

void f ();
void (&fr)() = f;
