// { dg-do assemble  }

const wchar_t *single  =   L"xyz"  ;
const wchar_t *(array[]) = { L"xyz" };
