/* Allow code to be shared between the FEs but avoid issues with
   C++-only flags.  */
#include "nsconstantstring-class-impl.h"
